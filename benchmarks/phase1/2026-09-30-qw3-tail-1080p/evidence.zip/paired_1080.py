import csv
import ctypes
import hashlib
import importlib.util
import json
import statistics
import subprocess
import zipfile
from pathlib import Path
from types import SimpleNamespace
from PIL import Image, ImageChops

root = Path.cwd()
folder = root / '.temp/phase1-quickwins/qw3-tail'
spec = importlib.util.spec_from_file_location('nrbench', root / 'tools/benchmark_nr_baseline.py')
bench = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bench)
testbed = root / 'dist/RequiemGame/RequiemGame.exe'
directory = testbed.parent
reference = folder / 'reference-build/Release/nrfusion_proxy.dll'
candidate = folder / 'candidate.dll'
carrier = directory / 'version.dll'
assert reference.is_file() and candidate.is_file()
power_status = (ctypes.c_ubyte * 12)()
assert ctypes.windll.kernel32.GetSystemPowerStatus(power_status) and power_status[0] == 1
original_config = {name: (directory / name).read_bytes() if (directory / name).exists() else None
                   for name in ['nrfusion.ini', 'nrfusion_advanced.ini']}
original_carrier = carrier.read_bytes()
results = {'reference_commit': '41b0828b563381e478cc4038294c8d8485c0ccd9',
           'candidate_commit': '09abdc437cfd6a64555ced166bc29e441282f4f0',
           'reference_sha256': bench.sha256(reference), 'candidate_sha256': bench.sha256(candidate),
           'gpu': subprocess.check_output(['nvidia-smi', '--query-gpu=name,uuid,driver_version',
                                          '--format=csv,noheader'], text=True).strip(),
           'power_scheme': subprocess.check_output(['powercfg', '/getactivescheme'], text=True).strip(),
           'settings': bench.SETTINGS, 'output': [1920, 1080], 'input': [1280, 720],
           'frames': 1200, 'warmup': 300, 'paired_repeats': 6, 'runs': []}
for label in ['reference', 'candidate']:
    (folder / label).mkdir(exist_ok=True)
telemetry_file = (folder / 'gpu-telemetry.csv').open('wb')
telemetry = subprocess.Popen(['nvidia-smi', '--query-gpu=timestamp,pstate,temperature.gpu,'
    'clocks.current.graphics,clocks.current.memory,power.draw,utilization.gpu', '--format=csv', '-l', '1'],
    stdout=telemetry_file, stderr=subprocess.STDOUT)
try:
    for repeat in range(6):
        for label in (['reference', 'candidate'] if repeat % 2 == 0 else ['candidate', 'reference']):
            print(f'PAIR {repeat + 1} {label}', flush=True)
            carrier.write_bytes((reference if label == 'reference' else candidate).read_bytes())
            args = SimpleNamespace(testbed=testbed, out=folder / label, frames=1200, warmup=300, timeout=180)
            result = bench.measure_run(args, 1080, repeat, True)
            assert bench.sha256(carrier) == results[label + '_sha256']
            with (args.out / result['case'] / 'evaluation.csv').open() as source:
                rows = list(csv.DictReader(source))
            for metric in ['nr_gpu_ms', 'ngx_evaluation_gpu_ms', 'frame_wall_ms']:
                result['metrics_ms'][metric]['p99'] = bench.percentile([float(row[metric]) for row in rows], .99)
            result['variant'] = label
            results['runs'].append(result)
finally:
    carrier.write_bytes(original_carrier)
    for name, contents in original_config.items():
        if contents is None:
            (directory / name).unlink(missing_ok=True)
        else:
            (directory / name).write_bytes(contents)
    telemetry.terminate()
    telemetry.wait(timeout=10)
    telemetry_file.close()
results['summary'] = {}
for metric in ['nr_gpu_ms', 'ngx_evaluation_gpu_ms', 'frame_wall_ms']:
    summary = {}
    for percentile in ['p50', 'p95', 'p99']:
        before = [run['metrics_ms'][metric][percentile] for run in results['runs'] if run['variant'] == 'reference']
        after = [run['metrics_ms'][metric][percentile] for run in results['runs'] if run['variant'] == 'candidate']
        changes = [100 * (candidate_value / reference_value - 1)
                   for reference_value, candidate_value in zip(before, after)]
        summary[percentile] = {'reference_median_ms': statistics.median(before),
                              'candidate_median_ms': statistics.median(after),
                              'paired_delta_percent': changes,
                              'median_paired_delta_percent': statistics.median(changes)}
    results['summary'][metric] = summary
with Image.open(folder / 'reference/1080p-01-nr-on/calculated.png') as before:
    with Image.open(folder / 'candidate/1080p-01-nr-on/calculated.png') as after:
        results['captured_rgb_exact'] = ImageChops.difference(before, after).getbbox() is None
assert results['captured_rgb_exact']
(folder / 'paired-result.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
print(json.dumps(results['summary'], indent=2), flush=True)
